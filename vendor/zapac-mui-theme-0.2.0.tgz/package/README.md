# @zapac/mui-theme

The **zapac** Material UI (v9) theme + custom components — a dual light/dark
glass-over-gradient system on the Zühlke purple→cyan identity.

## Install

This package is distributed as a **tarball** (no registry). Grab the `.tgz`
from a release and install it, then add the peer dependencies:

```bash
npm install ./zapac-mui-theme-0.2.0.tgz
npm install @mui/material @mui/icons-material @emotion/react @emotion/styled
```

Peer deps (you provide these): `react` `react-dom` `@mui/material`
`@mui/icons-material` `@emotion/react` `@emotion/styled`.

## Use

Wrap your app once. Every MUI component below the provider is themed.

```tsx
import { ZapacThemeProvider, ColorModeToggle } from '@zapac/mui-theme';
import '@zapac/mui-theme/fonts'; // optional — self-hosts Lato + JetBrains Mono

export function App() {
  return (
    <ZapacThemeProvider defaultMode="system">
      <ColorModeToggle />
      {/* your app */}
    </ZapacThemeProvider>
  );
}
```

Skip the `/fonts` import if your app already loads Lato / JetBrains Mono.

## Exports

| Export | What |
| --- | --- |
| `ZapacThemeProvider` | Theme boundary + `CssBaseline` + no-flash color-scheme script. |
| `theme` (alias `zapacTheme`) | The raw `createTheme` object, if you need to compose or wrap it yourself. |
| `ColorModeToggle` / `useColorMode` | Light/dark toggle and the hook behind it. |
| `AppHeader` | **v2** — the default sticky glass header: brand left, nav/actions, signed-in user + menu right. |
| `Modal` | **v2** — the house modal: `size="small" \| "medium" \| "large" \| "fullscreen"`, standardized title/✕/actions. |
| `FormField` `FormRow` `FormActions` | **v2** — standardized form anatomy: label → control → hint/error, responsive rows, footer button row. |
| `Sidebar` `Topbar` `CardHead` | The custom (non-MUI) components. |
| `navSections` + `NavItem` / `NavSection` types | Default sidebar nav data. |
| `@zapac/mui-theme/fonts` | Optional font side-effect import. |

## Forms (v2)

One anatomy for every control — external bold label, the control, then a
hint or error line. Put the bare input primitives inside (`OutlinedInput`,
`Select`, `Checkbox`, `RadioGroup`…), not `TextField` (it brings its own
label/FormControl):

```tsx
<FormRow>
  <FormField label="First name" required>
    <OutlinedInput value={first} onChange={…} />
  </FormField>
  <FormField label="Team" error={errors.team}>
    <Select value={team} onChange={…}>…</Select>
  </FormField>
</FormRow>
<FormActions>
  <Button variant="outlined">Cancel</Button>
  <Button type="submit">Save</Button>
</FormActions>
```

Buttons come in four variants in v2: `contained` (gradient primary, the
default), **`secondary`** (tonal chip-tint fill), `outlined` (ghost glass),
and `text`. Multiline fields (`multiline` on `OutlinedInput`/`TextField`) now
share the exact inner padding of single-line fields.

## Types

TypeScript module augmentation ships with the package and loads automatically
when you import from it — so `theme.zapac.*`, the custom palette groups
(`brand`, `glass`, `gradient`, `paneInk`), and the `<Typography variant="code">`
variant are all typed with no extra setup.

See [src/theme/README.md](./src/theme/README.md) for the theme's internal
architecture and design decisions.

## Releasing

```bash
npm run build            # → dist/ (JS + .d.ts)
npm pack                 # → zapac-mui-theme-<version>.tgz  (prepack rebuilds dist)
```

Attach the `.tgz` to a git tag / release. Bump `version` in `package.json` per
release (semver).
